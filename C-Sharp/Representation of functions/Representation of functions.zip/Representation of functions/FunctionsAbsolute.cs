﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Representation_of_functions
{
    class FunctionsAbsolute : Operations
    {
        protected void SubDivide(string[] parts)
        {
            //TO DO
        }
    }
}
