﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Representation_of_functions
{
    class Asymptotes
    {
        protected double resultAsymptote;
        protected void Vertical(string[] parts)
        {
            //TO DO
        }
        protected void Horizontal(string[] parts)
        {
            //TO DO
        }
        protected void Oblique(string[] parts)
        {
            //TO DO
        }
    }
}
