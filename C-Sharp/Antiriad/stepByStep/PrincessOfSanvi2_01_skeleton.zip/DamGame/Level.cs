﻿namespace DamGame
{
    class Level
    {
        public void DrawOnHiddenScreen()
        {
            // TO DO
        }

        public bool IsValidMove(int xMin, int yMin, int xMax, int yMax)
        {
            // TO DO
            return true;
        }
    }
}
