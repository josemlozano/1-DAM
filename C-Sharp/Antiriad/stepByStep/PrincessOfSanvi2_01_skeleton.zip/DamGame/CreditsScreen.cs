﻿namespace DamGame
{
    class CreditsScreen
    {
        public void Run()
        {
            // TO DO
        }
    }
}
